-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 18 2010 г., 14:41
-- Версия сервера: 5.0.51
-- Версия PHP: 5.2.6-1+lenny3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `oso_user_ratings`
--

CREATE TABLE IF NOT EXISTS `oso_user_ratings` (
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `rating` decimal(14,4) NOT NULL default '0.0000',
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oso_user_ratings`
--

INSERT INTO `oso_user_ratings` (`user_id`, `item_id`, `rating`) VALUES
(1, 1, 0.2000),
(1, 3, 0.1000),
(2, 1, 0.3000),
(2, 2, 0.1000),
(3, 2, 0.5000),
(3, 4, 0.1000),
(1, 4, 0.5000);
